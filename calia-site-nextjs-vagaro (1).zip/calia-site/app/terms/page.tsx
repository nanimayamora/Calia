import React from "react";

export const metadata = {
  title: "Terms of Service | Calia Functional Wellness & Aesthetics",
  description: "Terms of Service"
};

export default function Page() {
  return (
    <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="font-serif text-3xl">Terms of Service</h1>
      <div className="mt-4 space-y-4 text-neutral-700">
        <p>Use this as a placeholder until your official terms are ready.</p>
      </div>
    </main>
  );
}
