import React from "react";

export const metadata = {
  title: "HIPAA Notice of Privacy Practices | Calia Functional Wellness & Aesthetics",
  description: "HIPAA Notice of Privacy Practices"
};

export default function Page() {
  return (
    <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="font-serif text-3xl">HIPAA Notice of Privacy Practices</h1>
      <div className="mt-4 space-y-4 text-neutral-700">
        <p>Provide your HIPAA NPP here. This placeholder is not legal advice.</p>
      </div>
    </main>
  );
}
