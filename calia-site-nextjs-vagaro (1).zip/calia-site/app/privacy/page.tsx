import React from "react";

export const metadata = {
  title: "Privacy Policy | Calia Functional Wellness & Aesthetics",
  description: "Privacy Policy"
};

export default function Page() {
  return (
    <main className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-16">
      <h1 className="font-serif text-3xl">Privacy Policy</h1>
      <div className="mt-4 space-y-4 text-neutral-700">
        <p>This is a general informational template. Replace with your legal counsel's approved policy.</p>
      </div>
    </main>
  );
}
